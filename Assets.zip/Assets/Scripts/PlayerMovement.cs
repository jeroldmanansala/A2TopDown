using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;

    private Rigidbody2D rb;
    private Vector2 movement;
    private Animator anim;
    private Vector2 lastMoveDir = Vector2.down; // Default facing down

    private void Awake()
    {
    }
    

    void Start()
    {
        DontDestroyOnLoad(gameObject);

        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();

        GameObject spawn = GameObject.Find("spawn");
            if (spawn != null)
            {
                transform.position = spawn.transform.position;
            }
            }

    void Update()
    {

        // Get input
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");

        bool isMoving = movement != Vector2.zero;

        if (isMoving)
        {
            lastMoveDir = movement.normalized;
        }

        // Update Animator parameters
        anim.SetBool("IsMoving", isMoving);

        // Feed the blend tree either input or last direction
        anim.SetFloat("MoveX", isMoving ? movement.x : lastMoveDir.x);
        anim.SetFloat("MoveY", isMoving ? movement.y : lastMoveDir.y);

        if (Input.GetKeyDown(KeyCode.J))
        {
            anim.SetTrigger("Attack");
        }

        
    }

    void FixedUpdate()
    {
        rb.MovePosition(rb.position + movement.normalized * moveSpeed * Time.fixedDeltaTime);
    }


}
