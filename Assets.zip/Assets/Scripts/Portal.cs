using UnityEngine;

public class Portal : MonoBehaviour
{
    public int levelToLoad;
    public bool hasKey;

        void Start()
    {
        hasKey = false;
    }

    private void OnTriggerEnter2D(Collider2D coll)
    {
        if (hasKey)
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(levelToLoad);
        }
    }

}
