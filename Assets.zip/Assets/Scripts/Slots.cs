using UnityEngine;

public class Slots : MonoBehaviour
{
    public GameObject currentItem;
}
