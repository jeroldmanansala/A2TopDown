using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Slot : MonoBehaviour
{
    public void DropItem()
    {
        Debug.Log("ropItem() called from: " + gameObject.name);

        foreach (Transform child in transform)
        {
            if (child.name != "RemoveButton") // don't destroy the X
            {
                Destroy(child.gameObject);
            }
        }
    }
}


