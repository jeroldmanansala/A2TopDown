using UnityEngine;

public class Inv : MonoBehaviour
{
    public bool[] isFull;
    public GameObject[] slots;

    public GameObject droppedItemPrefab; // ← Optional prefab to spawn in world

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            for (int i = 0; i < slots.Length; i++)
            {
                if (isFull[i] && slots[i].transform.childCount > 0)
                {
                    // Get the item inside the slot
                    Transform item = slots[i].transform.GetChild(0);

                    // OPTIONAL: Drop item into world (like a pickup)
                    // Instantiate(droppedItemPrefab, transform.position, Quaternion.identity);

                    // Destroy the item from inventory UI
                    Destroy(item.gameObject);

                    // Mark slot as empty
                    isFull[i] = false;

                    Debug.Log("Item dropped from slot: " + i);
                    break;
                }
            }
        }
    }
}
