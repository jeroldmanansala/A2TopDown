using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Pickup : MonoBehaviour
{
    private Inv inv;
    public GameObject itemButton;

    private void Start()
    {
        inv = GameObject.FindGameObjectWithTag("Player").GetComponent<Inv>();
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.CompareTag("Player")) {
            for (int i=0;i<inv.slots.Length;i++)
            {
                if (inv.isFull[i] == false) {
                    inv.isFull[i] = true;
                    Instantiate(itemButton, inv.slots[i].transform, false);
                    Destroy(gameObject);
                    break;
                }
            }
        }
    }
}
